package med.voll.ForoHub.datos;

public record DatosCurso(
        Long id,
        String nombre,
        String categoria
) {}
