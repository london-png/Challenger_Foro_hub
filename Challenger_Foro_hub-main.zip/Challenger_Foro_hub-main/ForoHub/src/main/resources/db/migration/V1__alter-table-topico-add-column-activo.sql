alter table topico add activo tinyint;
update topico set activo = 1;