package med.voll.ForoHub.model;

public enum Status {
    ABIERTO,
    RESUELTO,
    PENDIENTE
}
